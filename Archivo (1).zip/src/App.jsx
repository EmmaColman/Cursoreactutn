import logo from "./logo.svg";
import "./App.css";
import Home from "./Home";
import Contador from "./Contador";

function App() {
  return (
    <div className="App">
      App
      <Home />
      <Contador />
    </div>
  );
}

export default App;
