//Componente tipo clase
import react, { Component } from "react";

class Contador extends Component {
  render() {
    return <div>Contador</div>;
  }
}

export default Contador;
