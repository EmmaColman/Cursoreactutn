//Componente tipo funcion
function Productos() {
  return <div>Productos</div>;
}

export default Productos;
